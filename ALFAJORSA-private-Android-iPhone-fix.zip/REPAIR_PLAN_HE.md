# תכנית תיקון ALFAJORSA — Android ו־iPhone, ללא פרסום

## אבחון

1. קוד הממשק נכתב ב־Expo/React Native ולכן הוא משותף ל־Android ול־iOS.
2. גרסאות התלויות במאגר תואמות ל־Expo SDK 57: React Native 0.86 ו־React 19.2.3.
3. ה־APK הקודם הוגדר כ־Debug, ולכן הוא אינו מתאים כאפליקציה עצמאית רגילה.
4. הבנייה המקומית ב־Codespace נכשלה משום שנתיב Android SDK לא הוגדר.
5. `SafeAreaView` שיובא מ־React Native מיושן; באייפון הוא עלול ליצור בעיות סביב ה־notch ופס הבית.
6. תהליך הבנייה בדק רק Android ולא בדק הידור של iOS.

## מה חבילת התיקון עושה

- מתקינה `react-native-safe-area-context` בגרסה המתאימה ל־Expo.
- מעדכנת את מסך האפליקציה לשימוש ב־Safe Area תקין ב־Android וב־iPhone.
- משמרת מזהים נפרדים:
  - Android: `com.alfajorsa.app`
  - iOS: `com.alfajorsa.app`
- משאירה את EAS במצב Preview פנימי בלבד.
- מוסיפה בדיקת Android Release עצמאית.
- מוסיפה בדיקת iPhone Simulator ללא חתימה.
- אינה מעלה APK/IPA כ־Artifact.
- אינה שולחת ל־Google Play, TestFlight או App Store.
- אינה מבצעת commit או push.

## איך מפעילים ב־Codespace

1. העלה את `apply_private_mobile_fix.sh` לתיקייה הראשית של ALFAJORSA.
2. פתח Terminal.
3. הרץ:

```bash
chmod +x apply_private_mobile_fix.sh
./apply_private_mobile_fix.sh
```

4. לאחר הסיום בדוק:

```bash
git status
git diff
```

## בדיקה על iPhone אמיתי בעתיד

- בדיקת Simulator ב־GitHub Actions אינה דורשת חשבון Apple.
- התקנה פרטית על iPhone אמיתי דורשת Apple Developer ו־UDID רשום, או TestFlight.
- אף אחד מהצעדים האלה אינו מתבצע בחבילה הנוכחית.
