ALFAJORSA private mobile repair

This package DOES NOT publish the app.

Files:
- apply_private_mobile_fix.sh — run inside the repository
- REPAIR_PLAN_HE.md — diagnosis and repair plan

Command:
  chmod +x apply_private_mobile_fix.sh
  ./apply_private_mobile_fix.sh

The script:
- creates backups
- changes local files only
- runs TypeScript and Expo Doctor checks
- never commits
- never pushes
- never uploads to an app store
